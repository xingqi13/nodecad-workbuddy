# 工具与制图检查

命令中的路径以技能目录为当前目录；Python 3.11+，安装 `scripts/requirements.txt` 所列依赖后使用。不要在未获授权时更改系统环境或覆盖已有文件。

- 女儿墙简图：`python scripts/nodecad.py --params examples/parapet-test.json --out <新文件.dxf>`。该示例是测试假设，不是工程尺寸；必须使用当前项目明确的全部参数，输出是简化原型。
- 屋面泛水研究图：`python scripts/detail_redraw.py --config examples/flashing-study-test.json --out <新文件.dxf>`。配置的尺寸、图形、字库路径及说明均为演示；先依据项目和可用字体准备新的配置，输出不自动成为施工图。
- 其他节点：按用户提供的资料和图面需求逐项实现；如依赖 AutoCAD、字库、图集或专门脚本，先确认可用再执行。需核对参考图而不是由相似节点臆造材料层或尺寸。

重点核对：原文与节点图号；尺寸对象、覆盖文字与测量值；图块变换与裁剪；填充、遮罩、前后顺序；字体和尺寸斜划；文字拥挤与实际输出比例。DXF 审计、对象数量和预览各有局限，不证明施工或规范符合。修改原 CAD 前另存到新路径。
