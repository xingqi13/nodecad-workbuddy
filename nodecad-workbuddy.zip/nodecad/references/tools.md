# 工具与制图检查

命令中的路径以技能目录为当前目录；Python 3.11+。两个 DXF 工具需安装 `scripts/requirements.txt` 所列依赖后使用。不要在未获授权时更改系统环境或覆盖已有文件。

- 地砖接浮铺木地板研究剖面（Python 标准库）：复制 `examples/floor-study.json` 并调整八个毫米参数，运行 `python scripts/floor_section.py --params examples/floor-study.json --out floor.svg`，浏览器打开 SVG。以结构板顶为基准，计算两侧标高、净缝和搭接。覆盖关系为示意，图中厚度按输入计算。用新输出路径。
- 女儿墙简图：`python scripts/nodecad.py --params examples/parapet-test.json --out <新文件.dxf>`。该示例是测试假设，不是工程尺寸；必须使用当前项目明确的全部参数，输出是简化原型。
- 屋面泛水研究图：`python scripts/detail_redraw.py --config examples/flashing-study-test.json --out <新文件.dxf>`。配置的尺寸、图形、字库路径及说明均为演示；先依据项目和可用字体准备新的配置，输出不自动成为施工图。
- 其他节点：按用户提供的资料和图面需求逐项实现；如依赖 AutoCAD、字库、图集或专门脚本，先确认可用再执行。需核对参考图而不是由相似节点臆造材料层或尺寸。

重点核对：原文与节点图号；尺寸对象、覆盖文字与测量值；图块变换与裁剪；填充、遮罩、前后顺序；字体和尺寸斜划；文字拥挤与实际输出比例。DXF 审计、对象数量和预览各有局限，不证明施工或规范符合。修改原 CAD 前另存到新路径。
