"""Original schematic geometry, millimetres. Not an engineering design."""
import argparse
import json
import math
import sys
from dataclasses import asdict, dataclass, fields
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'vendor'))
import ezdxf


@dataclass(frozen=True)
class Parapet:
    roof_length: float = 1200
    parapet_height: float = 650  # measured from top of structural slab
    wall_thickness: float = 200
    slab_thickness: float = 120
    insulation_thickness: float = 80
    coping_thickness: float = 60
    coping_overhang: float = 50

    def validate(self):
        for f in fields(self):
            value = getattr(self, f.name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f'{f.name} must be a positive finite number in mm')
        if self.insulation_thickness >= self.parapet_height:
            raise ValueError('insulation_thickness must be less than parapet_height')


def parse_params(data):
    if not isinstance(data, dict):
        raise ValueError('parameters must be a JSON object')
    required = {field.name for field in fields(Parapet)}
    missing = required - set(data)
    extra = set(data) - required
    if missing:
        raise ValueError('missing explicit parameters: ' + ', '.join(sorted(missing)))
    if extra:
        raise ValueError('unknown parameters: ' + ', '.join(sorted(extra)))
    params = Parapet(**data)
    params.validate()
    return params


def parse_json_bytes(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f'duplicate JSON key: {key}')
            result[key] = value
        return result
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique)


def make_geometry(p):
    p.validate()
    L, H, W, S, I, C, O = (p.roof_length, p.parapet_height, p.wall_thickness, p.slab_thickness, p.insulation_thickness, p.coping_thickness, p.coping_overhang)
    return {
        'SLAB': [(-L, -S), (0, -S), (0, 0), (-L, 0)],
        'WALL': [(0, -S), (W, -S), (W, H), (0, H)],
        'INSULATION': [(-L, 0), (0, 0), (0, I), (-L, I)],
        'MEMBRANE': [(-L, I), (0, I), (0, H), (W, H)],
        'COPING': [(-O, H), (W + O, H), (W + O, H + C), (-O, H + C)],
    }


def generate(p, output):
    geometry = make_geometry(p)
    doc = ezdxf.new('R2010', setup=True)
    doc.units = 4  # mm
    colors = {'SLAB': 7, 'WALL': 7, 'INSULATION': 3, 'MEMBRANE': 1, 'COPING': 5, 'NOTES': 7, 'DIMENSIONS': 2}
    for name, color in colors.items():
        doc.layers.new(name, dxfattribs={'color': color})
    msp = doc.modelspace()
    for name, vertices in geometry.items():
        msp.add_lwpolyline(vertices, close=name != 'MEMBRANE', dxfattribs={'layer': name})
    notes = [
        ('SCHEMATIC TEST ONLY - NOT FOR CONSTRUCTION', (-p.roof_length, p.parapet_height + p.coping_thickness + 150)),
        (f'WALL H={p.parapet_height:g} W={p.wall_thickness:g} mm', (-p.roof_length, p.parapet_height + p.coping_thickness + 90)),
        (f'SLAB={p.slab_thickness:g} INSULATION={p.insulation_thickness:g} mm', (-p.roof_length, p.parapet_height + p.coping_thickness + 45)),
        ('MEMBRANE: SCHEMATIC LINE / COPING: SCHEMATIC', (-p.roof_length, -p.slab_thickness - 90)),
    ]
    for text, point in notes:
        msp.add_text(text, dxfattribs={'layer': 'NOTES', 'height': 25, 'insert': point})
    # Dimensions are editable CAD entities regenerated from the model. Their
    # association is not maintained when users manually edit geometry in CAD.
    dim_options = {'dimtxt': 24, 'dimasz': 16, 'dimexe': 8, 'dimexo': 5,
                   'dimlfac': 1.0, 'dimdec': 3, 'dimzin': 8, 'dimdsep': 46}
    thickness = msp.add_linear_dim(base=(p.wall_thickness / 2, p.parapet_height + p.coping_thickness + 80),
                                   p1=(0, p.parapet_height), p2=(p.wall_thickness, p.parapet_height),
                                   angle=0, override=dim_options, dxfattribs={'layer': 'DIMENSIONS'})
    thickness.render()
    thickness.dimension.dxf.actual_measurement = thickness.dimension.get_measurement()
    height = msp.add_linear_dim(base=(p.wall_thickness + p.coping_overhang + 130, p.parapet_height / 2),
                                p1=(p.wall_thickness, 0), p2=(p.wall_thickness, p.parapet_height),
                                angle=90, override=dim_options, dxfattribs={'layer': 'DIMENSIONS'})
    height.render()
    height.dimension.dxf.actual_measurement = height.dimension.get_measurement()
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f'Refusing to overwrite: {output}')
    doc.saveas(output)
    return geometry


def main():
    parser = argparse.ArgumentParser(description='Generate a schematic parapet DXF; values are test assumptions in mm.')
    parser.add_argument('--params', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try:
        p = parse_params(parse_json_bytes(args.params.read_bytes()))
    except (OSError, ValueError, TypeError) as exc:
        parser.error(str(exc))
    generate(p, args.out)
    print(json.dumps({'output': str(args.out), 'parameters_mm': asdict(p), 'status': 'test only'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
