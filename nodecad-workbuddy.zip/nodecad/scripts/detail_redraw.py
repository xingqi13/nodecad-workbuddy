"""Generate a roof flashing study from new CAD primitives and explicit parameters.

No drawing import is used. Reference-specific notes belong in a private input JSON.
All dimensions are test values unless independently verified for an actual project.
"""
import argparse
from dataclasses import asdict, dataclass, fields
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
import ezdxf
from detail_refinements import DetailGraphics, install_layers, add_details


def _wall_top_profile(width, height):
    # Shape of the schematic break in the concrete outline, not a code rule.
    return [(0,height),(width*.43,height),(width*.48,height+32),
            (width*.55,height-32),(width*.60,height),(width,height)]


def _lowest_wall_top_over_chase(width, height, depth):
    profile = _wall_top_profile(width, height)
    candidates = [y for x, y in profile if x <= depth]
    for (x1,y1),(x2,y2) in zip(profile,profile[1:]):
        if x1 <= depth <= x2:
            candidates.append(y1+(y2-y1)*(depth-x1)/(x2-x1))
            break
    return min(candidates)


@dataclass(frozen=True)
class FlashingStudy:
    roof_run: float
    outside_run: float
    wall_thickness: float
    slab_thickness: float
    wall_top: float
    beam_depth: float
    lower_wall_depth: float
    levelling_thickness: float
    membrane_thickness: float
    separation_thickness: float
    insulation_thickness: float
    upper_mortar_thickness: float
    surface_thickness: float
    edge_gap: float
    upstand_top: float
    fixing_rise: float
    chase_depth: float
    chase_height: float
    corner_radius: float
    additional_width: float
    horizontal_detail_length: float

    def validate(self):
        for item in fields(self):
            value = getattr(self, item.name)
            if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or value <= 0:
                raise ValueError(item.name + ' must be positive and finite')
        if self.slab_thickness >= self.beam_depth or self.beam_depth >= self.lower_wall_depth:
            raise ValueError('require slab_thickness < beam_depth < lower_wall_depth')
        if self.roof_surface + self.corner_radius >= self.upstand_top:
            raise ValueError('upstand must be above roof build-up')
        if self.upstand_top + self.fixing_rise + 130 >= self.wall_top:
            raise ValueError('wall top leaves insufficient room for termination and dimension text')
        if self.chase_depth >= self.wall_thickness or self.edge_gap >= self.roof_run / 3:
            raise ValueError('invalid wall chase or roof edge gap')
        if self.upstand_top + self.chase_height >= _lowest_wall_top_over_chase(self.wall_thickness, self.wall_top, self.chase_depth):
            raise ValueError('wall chase meets or crosses the schematic wall top break')
        # outside_run is the end X coordinate measured from the wall's left
        # face; the schematic end break extends 22 test units back from it.
        if self.outside_run - 22 <= self.wall_thickness:
            raise ValueError('outside slab end break must remain outside the wall')
        if self.additional_width + self.corner_radius >= self.roof_run:
            raise ValueError('additional strip must fit roof run')
        if self.membrane_thickness >= self.corner_radius:
            raise ValueError('membrane thickness must be less than corner radius')

    @property
    def membrane_level(self):
        return self.levelling_thickness + self.membrane_thickness

    @property
    def roof_surface(self):
        return self.membrane_level + self.separation_thickness + self.insulation_thickness + self.upper_mortar_thickness + self.surface_thickness


LAYERS = {
    'NC-CONCRETE': (2, 25), 'NC-CONCRETE-HATCH': (1, 9),
    'NC-MASONRY': (2, 25), 'NC-MASONRY-HATCH': (1, 9),
    'NC-ROOF': (2, 18), 'NC-INSULATION': (1, 9),
    'NC-MEMBRANE': (4, 30), 'NC-ADDITIONAL': (4, 18),
    'NC-FOAM': (4, 18), 'NC-METAL': (4, 25), 'NC-SEALANT': (1, 9),
    'NC-REBAR': (1, 30), 'NC-DIM': (3, 13),
    'NC-LEADER': (3, 13), 'NC-NOTE': (7, 13), 'NC-LEVEL': (6, 13),
    'NC-BREAK': (3, 18), 'NC-TITLE': (7, 18), 'NC-STATUS': (8, 9),
}


def build(p, notes, font, bigfont, detail_graphics=None):
    """Construct a fresh document; inputs contain parameters and text only."""
    p.validate()
    graphics=DetailGraphics(**(detail_graphics or {}))
    graphics.validate(p)
    if graphics.enabled and p.roof_run <= p.edge_gap + 24:
        raise ValueError('roof build-up has no horizontal space for the graphic edge offset')
    if not graphics.enabled and (p.chase_depth <= 7 or p.chase_height <= 8):
        raise ValueError('wall chase is too small for the schematic sealant rectangle')
    required = {'nail', 'sealant', 'roof', 'roof_reference', 'additional', 'edge', 'rebar', 'roof_datum'}
    if set(notes) != required or any(not isinstance(s, str) or not s.strip() for s in notes.values()):
        raise ValueError('supply all note strings explicitly')
    doc = ezdxf.new('R2010', setup=True)
    doc.units = 4
    doc.header['$MEASUREMENT'] = 1
    for name, (color, weight) in LAYERS.items():
        doc.layers.new(name, dxfattribs={'color': color, 'lineweight': weight})
    if graphics.enabled:
        install_layers(doc)
    doc.styles.new('NC-CJK', dxfattribs={'font': str(font), 'bigfont': str(bigfont), 'width': 1})
    for style in doc.styles:
        if style.dxf.name != 'NC-CJK':
            style.dxf.font = 'txt.shx'
            style.dxf.bigfont = ''
    m = doc.modelspace()

    def line(a, b, layer):
        return m.add_line(a, b, dxfattribs={'layer': layer})

    def poly(points, layer, closed=False):
        return m.add_lwpolyline(points, close=closed, dxfattribs={'layer': layer})

    def text(value, point, height=35, layer='NC-NOTE'):
        return m.add_text(value, dxfattribs={'insert': point, 'height': height, 'style': 'NC-CJK', 'layer': layer, 'width': 1})

    def rect(x0, y0, x1, y1, layer):
        points = [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
        poly(points, layer, True)
        return points

    def hatch(points, layer, pattern='ANSI31', scale=8, angle=0):
        h = m.add_hatch(dxfattribs={'layer':layer})
        h.paths.add_polyline_path(points, is_closed=True)
        h.set_pattern_fill(pattern, color=256, scale=scale, angle=angle)
        return h

    def note(value, x, y, near, far, target):
        # Start the leader at the OUTER end of the landing on either side of
        # the section. Starting under a right-hand label and reversing at its
        # far end traces the same line twice. Text and leader remain editable.
        for i, row in enumerate(value.split('\n')):
            text(row, (x,y-i*55))
        points = [(far,y-10),(near,y-10),target]
        poly(points, 'NC-LEADER')
        if graphics.enabled:
            return
        # Filled CAD arrow at the referenced construction component.
        a, b = points[-2], points[-1]
        dx,dy=a[0]-b[0],a[1]-b[1]
        length=math.hypot(dx,dy)
        ux,uy=dx/length,dy/length
        q=(b[0]+18*ux,b[1]+18*uy)
        arrow=[b,(q[0]-5*uy,q[1]+5*ux),(q[0]+5*uy,q[1]-5*ux)]
        h=m.add_hatch(color=256,dxfattribs={'layer':'NC-LEADER'})
        h.paths.add_polyline_path(arrow,is_closed=True)

    L,R,W,S=p.roof_run,p.outside_run,p.wall_thickness,p.slab_thickness
    H,B,D=p.wall_top,p.beam_depth,p.lower_wall_depth
    U,C,G=p.upstand_top,p.chase_depth,p.edge_gap
    # One connected concrete section, including a small termination chase.
    concrete=[(-L,0),(0,0),(0,U),(C,U),(C,U+p.chase_height),
              (0,U+p.chase_height),*_wall_top_profile(W,H),(W,0),(R,0),
              (R,-S*.28),(R+22,-S*.37),(R-22,-S*.49),(R,-S*.60),
              (R,-S),(W,-S),(W,-B),(0,-B),(0,-S),(-L,-S)]
    poly(concrete,'NC-CONCRETE',True)
    hatch(concrete,'NC-CONCRETE-HATCH','AR-CONC',0.65)
    hatch(concrete,'NC-CONCRETE-HATCH','ANSI31',28)
    masonry=[(0,-B),(W,-B),(W,-D),(W*.60,-D),(W*.55,-D-28),
             (W*.48,-D+28),(W*.43,-D),(0,-D)]
    poly(masonry,'NC-MASONRY',True)
    hatch(masonry,'NC-MASONRY-HATCH','ANSI31',12)
    hatch(masonry,'NC-MASONRY-HATCH','ANSI31',12,90)
    break_extension=max(30,W*.16)  # study drawing choice; not a claimed standard value
    poly([(-break_extension,H),(0,H),(W*.43,H),(W*.48,H+32),(W*.55,H-32),(W*.60,H),(W,H),(W+break_extension,H)],'NC-BREAK')
    poly([(-break_extension,-D),(0,-D),(W*.43,-D),(W*.48,-D+28),(W*.55,-D-28),(W*.60,-D),(W,-D),(W+break_extension,-D)],'NC-BREAK')

    # Roof layers are explicit test geometry, not a specification of a real roof.
    y=p.levelling_thickness
    roof_right=-G-24 if graphics.enabled else -G
    outlines='NC-LAYER-SEPARATOR' if graphics.enabled else 'NC-ROOF'
    points=rect(-L,0,-12 if graphics.enabled else -G,y,'NC-ROOF')
    if not graphics.enabled:
        hatch(points,'NC-ROOF','ANSI31',7)
    membrane_y=p.membrane_level
    separation_top=membrane_y+p.separation_thickness
    rect(-L,membrane_y,roof_right,separation_top,outlines)
    insulation_top=separation_top+p.insulation_thickness
    points=rect(-L,separation_top,roof_right,insulation_top,outlines)
    hatch(points,'NC-INSULATION','HONEY',3)
    mortar_top=insulation_top+p.upper_mortar_thickness
    rect(-L,insulation_top,roof_right,mortar_top,outlines)
    points=rect(-L,mortar_top,roof_right,p.roof_surface,'NC-ROOF')
    hatch(points,'NC-CONCRETE-HATCH','AR-CONC',0.45)
    if graphics.enabled:
        hatch(points,'NC-CONCRETE-HATCH','ANSI31',16,90)
    else:
        foam=rect(-G,membrane_y,0,p.roof_surface,'NC-FOAM')
        hatch(foam,'NC-FOAM','ANSI31',3)
    # Two continuous rounded membrane boundaries, with independently generated arcs.
    paths=[]
    membrane_layer='NC-DETAIL-LOGIC' if graphics.enabled else 'NC-MEMBRANE'
    for offset in (0,p.membrane_thickness):
        radius=p.corner_radius-offset
        x0=-12-p.corner_radius
        center_y=y+p.corner_radius
        end_x=x0+radius
        y0=y+offset
        points=[(-L,y0),(x0,y0)]
        poly(points,membrane_layer)
        m.add_arc((x0,center_y),radius,270,360,dxfattribs={'layer':membrane_layer})
        poly([(end_x,center_y),(end_x,U+offset),(C,U+offset)],membrane_layer)
        paths.append({'level':y0,'vertical_x':end_x,'corner_center':[x0,y0+radius],
                      'radius':radius,'end_height':U+offset})
    add_radius=p.corner_radius+9
    # Keep this short additional strip visible on paper and leave a distinct
    # vertical line beside the two graphical traces, even through the turn.
    add_x=min(-24,-12-graphics.trace_spacing-10) if graphics.enabled else -24
    x0=add_x-add_radius
    y0=y-7
    if -p.additional_width >= x0 or y0 <= 0:
        raise ValueError('additional strip needs space for a visible horizontal landing and turn')
    additional_layer='NC-ADDITIONAL'
    poly([(-p.additional_width,y0),(x0,y0)],additional_layer)
    m.add_arc((x0,y0+add_radius),add_radius,270,360,dxfattribs={'layer':additional_layer})
    line((add_x,y0+add_radius),(add_x,p.roof_surface+75),additional_layer)

    # New metal termination strip, a fastener and sealant, all ordinary CAD objects.
    nail_x=C*.42
    if graphics.enabled:
        details=add_details(doc,p,graphics)
        nail_target=tuple(details['nail_head_center'])
        edge_target=tuple(details['edge_note_target'])
        sealant_target=(C/2,U+(18+p.fixing_rise)/2)
    else:
        poly([(-27,U-75),(-27,U+15),(C,U+15)],'NC-METAL')
        rect(3,U+5,C-4,U+p.chase_height-3,'NC-SEALANT')
        seal=m.add_hatch(color=256,dxfattribs={'layer':'NC-SEALANT'})
        seal.paths.add_polyline_path([(3,U+5),(C-4,U+5),(C-4,U+p.chase_height-3),(3,U+p.chase_height-3)],is_closed=True)
        line((nail_x,U+12),(nail_x,U+p.fixing_rise),'NC-METAL')
        line((nail_x-15,U+p.fixing_rise),(nail_x+15,U+p.fixing_rise),'NC-METAL')
        details=None
        nail_target=(nail_x,U+p.fixing_rise-8)
        edge_target=(-G/2,p.roof_surface*.68)
        sealant_target=((C-1)/2,U+(p.chase_height+2)/2)
    # New continuous diagrammatic bar: the two bottom hooks return inward.
    # This reproduces the observed topology, not a structural anchorage design.
    left,right=W*.30,W*.76
    hook_radius=W*.068
    bar_top=p.roof_surface*.72
    bar_bottom=-B+65
    bar_points=[(right-2*hook_radius,bar_bottom,1), (right,bar_bottom,0),
                (right,bar_top,0), (left,bar_top,0), (left,bar_bottom,1),
                (left+2*hook_radius,bar_bottom,0)]
    m.add_lwpolyline(bar_points,format='xyb',dxfattribs={'layer':'NC-REBAR'})
    line((-p.horizontal_detail_length,-70),(left,-70),'NC-REBAR')

    # Overall note layout, recomputed from parameters rather than copied coordinates.
    note(notes['nail'],-610,H-75,-270,-615,nail_target)
    note(notes['sealant'],W+270,U+140,W+250,W+610,sealant_target)
    roof_note_y=min(p.roof_surface+200,U-105) if graphics.enabled else p.roof_surface+270
    text(notes['roof'],(-620,roof_note_y))
    text(notes['roof_reference'],(-620,roof_note_y-62))
    roof_anchor_x = -650 if -L < -650 < roof_right else (-L+roof_right)/2
    poly([(roof_anchor_x,p.roof_surface),(-650,roof_note_y-15),(-220,roof_note_y-15)],'NC-LEADER')
    add_target=((-p.additional_width+x0)/2,y0)
    note(notes['additional'],-1220,-210,-600,-1225,add_target)
    note(notes['edge'],-1220,-420,-520,-1225,edge_target)
    # Annotate the right leg from the right side below the slab. The previous
    # diagonal from the lower left crossed the horizontal-detail dimension.
    bar_y=(bar_top+bar_bottom)/2
    note(notes['rebar'],W+320,bar_y-230,W+300,W+625,(right,bar_y))
    text(notes['roof_datum'],(-1430,110),35,'NC-LEVEL')
    poly([(-1430,92),(-1140,92),(-1060,0),(-980,92),(-1140,92)],'NC-LEVEL')
    line((-1200,0),(-935,0),'NC-LEVEL')
    text('FL',(W+350,110),35,'NC-LEVEL')
    poly([(W+250,92),(W+330,0),(W+410,92),(W+250,92)],'NC-LEVEL')
    line((W+220,0),(W+610,0),'NC-LEVEL')

    dimspecs=[]
    opts={'dimtxsty':'NC-CJK','dimtxt':35,'dimasz':23,'dimblk':'ARCHTICK',
          'dimexe':18,'dimexo':12,'dimgap':18,'dimclrd':3,'dimclre':3,
          'dimclrt':7,'dimtad':1,'dimdec':0,'dimzin':8,'dimlfac':1.0}
    def dimension(name,a,b,base,angle,background_mask=False):
        # The recess text is intentionally over the concrete hatch. Preserve
        # the hatch geometry, but mask it locally behind the dimension text.
        # This is an explicit drafting choice, not a general collision check.
        dim_options = dict(opts)
        if background_mask:
            dim_options['dimtfill'] = 1  # use the current drawing background
        d=m.add_linear_dim(base=base,p1=a,p2=b,angle=angle,override=dim_options,
                           dxfattribs={'layer':'NC-DIM'})
        d.render()
        value=float(d.dimension.get_measurement())
        d.dimension.dxf.actual_measurement=value
        dimspecs.append({'name':name,'handle':d.dimension.dxf.handle,'measurement':value,'unit':'mm_test'})
    dimension('upstand_from_structural_top',(0,0),(0,U),(-840,0),90)
    dimension('fixing_rise',(0,U),(0,U+p.fixing_rise),(-840,U),90)
    dimension('termination_recess',(0,U),(C,U),(0,U+p.fixing_rise+15),0,background_mask=True)
    dimension('horizontal_detail',(-p.horizontal_detail_length,-70),(0,-70),(0,-350),0)
    # Detail roundel, ruled title and nominal scale on one baseline. These
    # are paper-space design choices for this 1:10 study, expressed in mm.
    from ezdxf.enums import TextEntityAlignment
    title_y=min(-965,-D-170)
    cx=-450
    m.add_circle((cx,title_y),50,dxfattribs={'layer':'NC-TITLE'})
    text('1',(cx,title_y),45,'NC-TITLE').set_placement((cx,title_y),align=TextEntityAlignment.MIDDLE_CENTER)
    text('屋面女儿墙泛水节点',(cx+85,title_y),50,'NC-TITLE')
    text('1:10',(cx+560,title_y),35,'NC-TITLE')
    line((cx+50,title_y-14),(cx+660,title_y-14),'NC-TITLE')
    text('试绘尺寸，非施工设计。',(cx+85,title_y-80),30,'NC-STATUS')
    doc.set_modelspace_vport(height=2200,center=(-200,-100))
    # Advisory window retains the original study layout and expands around
    # the parameterized section and horizontal detail, with a small margin.
    # It is not a bounding box for text, dimensions, or every CAD entity.
    window_margin=40
    plot_window=[
        [min(-1560,-L-window_margin,-p.horizontal_detail_length-window_margin,
             -break_extension-window_margin),
         min(-1180,-D-28-window_margin,title_y-120)],
        [max(1210,R+22+window_margin,W+break_extension+window_margin),
         max(940,H+32+window_margin)],
    ]
    return doc, {'construction':'fresh ezdxf document; new primitives only; no source drawing imported',
                 'parameters_mm_test':asdict(p),'roof_surface_test':p.roof_surface,
                 'membrane_paths':paths,'dimensions':dimspecs,
                 'detail_graphics':details,'additional_note_target':list(add_target),
                 'paper_expression':{'nominal_scale':'1:10','detail_number':'1',
                                     'title_height_model_mm':50,'note_height_model_mm':35},
                 'break_extension_test':break_extension,
                 'rebar_topology':{'left_hook':'right_inward','right_hook':'left_inward',
                                   'top_bridge':True,'hook_radius_test':hook_radius,
                                   'bar_top_test':bar_top,'bar_bottom_test':bar_bottom},
                 'plot_window':plot_window,
                 'limits':['reference-based redrawing, not an independently invented construction system',
                           'unlabelled dimensions are explicit test assumptions',
                           'plot window is advisory; text, dimensions and actual CAD plotting require review',
                           'no project suitability or code compliance established']}


def generate(config, output):
    p=FlashingStudy(**config['parameters_mm_test'])
    output=Path(output)
    if output.exists(): raise FileExistsError(output)
    doc,meta=build(p,config['notes'],config['fonts']['font'],config['fonts']['bigfont'],config.get('detail_graphics'))
    doc.saveas(output)
    meta['dxf_sha256']=hashlib.file_digest(output.open('rb'),'sha256').hexdigest()
    meta['source_reference']=config['source_reference']
    meta['parameter_basis']=config['parameter_basis']
    return meta


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    cfg=json.loads(args.config.read_text(encoding='utf8'))
    result=generate(cfg,args.out)
    manifest=args.out.with_suffix('.manifest.json')
    with manifest.open('x',encoding='utf8') as f: json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps({'output':str(args.out),'dimensions':len(result['dimensions'])},ensure_ascii=False))


if __name__=='__main__': main()
