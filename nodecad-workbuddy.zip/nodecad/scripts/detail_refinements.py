"""Optional reference-detail graphics built from original parametric primitives.

Graphic offsets, pitches and nail sizes are study assumptions, not design rules.
Dash gaps are CAD representation; no material discontinuity is inferred.
"""
from dataclasses import asdict, dataclass, fields
import math


@dataclass(frozen=True)
class DetailGraphics:
    enabled: bool = False
    trace_spacing: float = 12
    trace_width: float = 4
    dash_length: float = 105
    dash_gap: float = 24
    lap_step: float = 5
    vertical_hatch_pitch: float = 2
    interface_pitch: float = 22
    interface_amplitude: float = 8

    def validate(self, p):
        if type(self.enabled) is not bool:
            raise ValueError('graphics enabled must be boolean')
        for item in fields(self):
            if item.name == 'enabled':
                continue
            value = getattr(self, item.name)
            if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or value <= 0:
                raise ValueError(item.name + ' must be positive and finite')
        if not self.enabled:
            return
        if self.trace_spacing >= p.corner_radius or self.trace_width >= self.trace_spacing:
            raise ValueError('invalid graphic trace spacing or width')
        if p.membrane_thickness + p.separation_thickness <= self.trace_spacing + self.lap_step + self.trace_width / 2:
            raise ValueError('graphic traces collide with roof build-up; reserve explicit test clearance')
        if p.chase_height < p.fixing_rise or p.fixing_rise <= 18:
            raise ValueError('termination graphic does not fit chase')
        if self.trace_spacing <= self.trace_width + 2:
            raise ValueError('trace graphics are not distinguishable')


EXTRA_LAYERS = {
    'NC-DETAIL-LOGIC': (4, 9), 'NC-SECOND-TRACE': (4, 30),
    'NC-FASTENER': (4, 18), 'NC-TERM-FILL': (1, 9),
    'NC-FOAM-FILL': (1, 9), 'NC-JOINT-FILL': (1, 9),
    'NC-INTERFACE': (2, 18), 'NC-LAYER-SEPARATOR': (4, 13),
    'NC-LEVELLING-HATCH': (1, 9),
}


def install_layers(doc):
    for name, (color, weight) in EXTRA_LAYERS.items():
        doc.layers.new(name, dxfattribs={'color': color, 'lineweight': weight})
    # Analytical aid only: dashed graphics must not be interpreted as real gaps.
    doc.layers.get('NC-DETAIL-LOGIC').dxf.plot = 0
    doc.layers.get('NC-DETAIL-LOGIC').off()


def add_details(doc, p, g):
    m = doc.modelspace()
    U, C, G = p.upstand_top, p.chase_depth, p.edge_gap

    def poly(points, layer, closed=False):
        return m.add_lwpolyline(points, close=closed, dxfattribs={'layer': layer})

    def box(x0, y0, x1, y1, layer):
        points = [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
        poly(points, layer, True)
        return points

    def vertical_fill(points, layer):
        h = m.add_hatch(color=256,dxfattribs={'layer':layer})
        h.paths.add_polyline_path(points,is_closed=True)
        h.set_pattern_fill('NC-VERTICAL',color=256,definition=[(90,(0,0),(g.vertical_hatch_pitch,0),[])])
        return h

    # Separate, staggered display traces. These are not declarations of ply count.
    cycle = g.dash_length + g.dash_gap
    doc.linetypes.new('NC-SHEET-A',dxfattribs={'description':'simple sheet graphic; no SHX dependency',
        'pattern':[cycle,g.dash_length,-g.dash_gap]})
    alternate_dash=g.dash_length-g.trace_spacing
    if alternate_dash<=g.trace_width:
        raise ValueError('alternate graphic dash is too short')
    doc.linetypes.new('NC-SHEET-B',dxfattribs={'description':'alternate sheet graphic; no SHX dependency',
        'pattern':[alternate_dash+g.dash_gap,alternate_dash,-g.dash_gap]})
    cx = -12-p.corner_radius
    traces = []
    for index in (0,1):
        offset = g.trace_spacing*index
        step = g.lap_step*index
        radius = p.corner_radius-offset
        level = p.levelling_thickness+offset
        cy = p.levelling_thickness+p.corner_radius+step
        x = cx+radius
        points = [(-p.roof_run+30,level,0)]
        if index:
            points.extend([(-p.roof_run*.60,level,0),(-p.roof_run*.51,level+step,0)])
        points.extend([(cx,level+step,math.tan(math.pi/8)),(x,cy,0),
                       (x,U+offset,0),(C+12,U+offset,0)])
        layer = 'NC-SECOND-TRACE' if index == 0 else 'NC-MEMBRANE'
        entity = m.add_lwpolyline(points,format='xyb',dxfattribs={
            'layer':layer,'linetype':'NC-SHEET-B' if index == 0 else 'NC-SHEET-A',
            'const_width':g.trace_width,'flags':0})
        traces.append({'handle':entity.dxf.handle,'layer':layer,'spacing_role':'graphical only',
                       'lap_step_test':step,'vertical_x':x,'arc_radius':radius,
                       'vertices_xyb':[list(point) for point in points]})

    # Visible packing above the sheet return, with a slanted, headed fastener.
    packing = box(0,U+18,C,U+p.fixing_rise,'NC-METAL')
    vertical_fill(packing,'NC-TERM-FILL')
    head = (C*.12,U+p.fixing_rise*.80)
    along = (math.sqrt(.5),-math.sqrt(.5))
    across = (math.sqrt(.5),math.sqrt(.5))
    head_length, head_width = C*.43, C*.10
    head_points = [(head[0]+sx*across[0]*head_length/2+sy*along[0]*head_width/2,
                    head[1]+sx*across[1]*head_length/2+sy*along[1]*head_width/2)
                   for sx,sy in [(-1,-1),(1,-1),(1,1),(-1,1)]]
    poly(head_points,'NC-FASTENER',True)
    shank_start = (head[0]+along[0]*head_width/2,head[1]+along[1]*head_width/2)
    tip = (head[0]+along[0]*C*1.12,head[1]+along[1]*C*1.12)
    half_width = C*.022
    poly([(shank_start[0]-across[0]*half_width,shank_start[1]-across[1]*half_width),
          (tip[0]-across[0]*half_width,tip[1]-across[1]*half_width),tip,
          (tip[0]+across[0]*half_width,tip[1]+across[1]*half_width),
          (shank_start[0]+across[0]*half_width,shank_start[1]+across[1]*half_width)],'NC-FASTENER',True)
    # Extend the visible outer profile down to the structural datum as a
    # drawing-study choice; its material and termination remain to be verified.
    outer_x=-G-24
    poly([(-30,U+125),(-30,U+45),(outer_x,U+9),(outer_x,0)],'NC-METAL')

    # Two separate vertical strips: their meanings are not collapsed into one material.
    insulation_base = p.membrane_level+p.separation_thickness
    upper = box(-G-24,insulation_base,-24,insulation_base+p.insulation_thickness,'NC-FOAM')
    vertical_fill(upper,'NC-FOAM-FILL')
    lower = box(-12,0,0,p.levelling_thickness,'NC-SEALANT')
    vertical_fill(lower,'NC-JOINT-FILL')

    # Symbolic interface, not a claim that the concrete is physically saw-toothed.
    cycles = max(1,round(p.wall_thickness/g.interface_pitch))
    step_x = p.wall_thickness/(cycles*2)
    zigzag = [(0,0)]
    for i in range(1,cycles*2):
        zigzag.append((i*step_x,g.interface_amplitude if i%2 else -g.interface_amplitude))
    zigzag.append((p.wall_thickness,0))
    poly(zigzag,'NC-INTERFACE')

    # Levelling graphic made of short triples, with no missing shape-font dependency.
    region = [(-p.roof_run,0),(-12,0),(-12,p.levelling_thickness),(-p.roof_run,p.levelling_thickness)]
    h = m.add_hatch(color=256,dxfattribs={'layer':'NC-LEVELLING-HATCH'})
    h.paths.add_polyline_path(region,is_closed=True)
    h.set_pattern_fill('NC-TRIPLES',color=256,definition=[
        (90,(shift,4),(42,0),[5,-15]) for shift in (0,3,6)])
    # No shared leader between the lower joint and the termination packing:
    # their appearance does not establish identical material or specification.
    return {'graphics':asdict(g),'visible_traces':traces,
            'nail_head_center':list(head),'nail_tip':list(tip),
            'nail_axis_direction':list(along),
            'outer_profile_bottom_test':[outer_x,0],
            'upper_strip':upper,'lower_strip':lower,'termination_packing':packing,
            'interface_vertices':zigzag,
            'edge_note_target':[-24-G/2,insulation_base+p.insulation_thickness/2],
            'features':['diagonal_headed_fastener','hatched_termination_packing',
                        'separate_staggered_traces','lap_step','upper_and_lower_vertical_strips',
                        'zigzag_interface','offset_metal_cover','levelling_triples'],
            'limits':['graphical offsets and pattern spacing are test assumptions',
                      'separate traces do not establish material identity or waterproof ply count',
                      'dash gaps are not actual material discontinuities']}
