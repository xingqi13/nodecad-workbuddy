"""Draw a dry interior floor junction study using only the Python standard library."""

import argparse
import json
import math
from pathlib import Path
from xml.etree import ElementTree as ET


FIELDS = ("tile_mm", "adhesive_mm", "tile_screed_mm", "wood_mm", "underlay_mm",
          "wood_screed_mm", "clear_gap_mm", "cover_reach_mm")


def dimensions(data):
    if not isinstance(data, dict) or set(data) != set(FIELDS):
        raise ValueError("参数应完整包含 " + ", ".join(FIELDS))
    for field in FIELDS:
        value = data[field]
        if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"{field} 需要有限正数（mm）")
    if data["cover_reach_mm"] <= data["clear_gap_mm"]:
        raise ValueError("盖翼伸出量须大于木侧净缝才有搭接")
    return [data[key] for key in FIELDS]


def draw(data):
    tile, adhesive, left_base, wood, pad, right_base, gap, reach = dimensions(data)
    left = left_base + adhesive + tile
    right = right_base + pad + wood
    root = ET.Element("svg", xmlns="http://www.w3.org/2000/svg", viewBox="0 0 1000 600",
                      width="1000", height="600", role="img")
    ET.SubElement(root, "title").text = "地砖接浮铺木地板剖面研究图"
    ET.SubElement(root, "rect", x="0", y="0", width="1000", height="600", fill="white")
    group = ET.SubElement(root, "g", {"font-family": "sans-serif", "fill": "#182025"})
    scale = min(230 / max(left, right), 270 / reach)
    joint, datum = 490, 407
    y = lambda z: datum - z * scale
    wood_edge = joint + gap * scale
    cover_tip = joint + reach * scale

    def line(x1, y1, x2, y2, width=1, dashed=False):
        ET.SubElement(group, "line", x1=str(x1), y1=str(y1), x2=str(x2), y2=str(y2),
                      stroke="#222", **{"stroke-width": str(width),
                                         "stroke-dasharray": "5 3" if dashed else "none"})

    def label(x, yy, content, size=15, anchor="start"):
        ET.SubElement(group, "text", x=str(x), y=str(yy),
                      **{"font-size": str(size), "text-anchor": anchor}).text = content

    def layer(x1, x2, bottom, top, color):
        ET.SubElement(group, "rect", x=str(x1), y=str(y(top)), width=str(x2-x1),
                      height=str((top-bottom)*scale), fill=color, stroke="#263238")

    def chain(x, edge, levels):
        line(x, y(levels[0]), x, y(levels[-1]))
        for height in levels:
            yy = y(height)
            line(x, yy, edge, yy, dashed=True)
            line(x-4, yy+4, x+4, yy-4, 1.5)
        for low, high in zip(levels, levels[1:]):
            label(x-6, y((low+high)/2)+4, f"{high-low:g}", 13, "end")

    label(44, 50, "地砖与浮铺木地板交接", 30)
    label(44, 82, "干区方案剖面   /   共用结构板基准   /   尺寸 mm", 17)
    label(140, 125, f"瓷砖 {tile:g}   ·   胶层 {adhesive:g}   ·   找平 {left_base:g}")
    label(555, 125, f"木板 {wood:g}   ·   地垫 {pad:g}   ·   找平 {right_base:g}")
    layer(145, joint, 0, left_base, "#dfddda")
    layer(145, joint, left_base, left_base+adhesive, "#ede1bb")
    layer(145, joint, left_base+adhesive, left, "#cadde3")
    layer(joint, 835, 0, right_base, "#dfddda")
    layer(wood_edge, 835, right_base, right_base+pad, "#dce6ce")
    layer(wood_edge, 835, right_base+pad, right, "#e4c995")
    line(145, datum, 835, datum, 2)
    # The diagram indicates horizontal reach only. A product section needs its own height.
    cap_y = y(max(left, right))-11
    line(joint, cap_y, cover_tip, cap_y, 2)
    line(joint, cap_y, joint, y(left_base), 2)
    chain(115, 145, [0, left_base, left])
    chain(860, 835, [0, right_base, right])
    label(145, 439, f"砖侧构造厚 {left:g}     木侧构造厚 {right:g}     木侧相对砖侧高差 {right-left:+g}")
    label(145, 474, f"木侧净缝 {gap:g}     盖翼自竖肋伸出 {reach:g}     搭接 {reach-gap:g}")
    label(44, 526, "上部薄层合并标注，各层厚度见图上分层说明。标注基准为结构板顶。")
    label(44, 555, "型材按水平覆盖关系示意。安装高度、固定方式、伸缩余量及防潮条件按实选系统复核。", 14)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--params", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    try:
        svg = draw(json.loads(args.params.read_text(encoding="utf-8-sig")))
        with args.out.open("xb") as output:
            output.write(svg)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"{exc}\n")


if __name__ == "__main__":
    main()
