---
name: nodecad
version: 1.2.0
display_name: NodeCAD建筑节点大样助手
display_name_en: NodeCAD-Architectural-Detail-Assistant
description: 根据项目参数绘制或审查建筑节点大样，支持离线构造分析、尺寸复核、屋面 DXF 和地材交接 SVG。
description_zh: 无需本地图集即可分析屋面、窗墙、地下防水、吊顶、门套及地材交接，组织分层剖面、引线和连续尺寸，复核材料收头、排水、受力和检修路径。内置可调参的女儿墙、屋面泛水 DXF 原型与地材交接 SVG。附两本制图标准及室内装饰图集、验收、防火、照明的审图方法和回查线索。
description_en: Draft and review building details offline using project parameters and bundled construction and drafting guides. Generate roof and parapet DXF studies or a floor junction SVG. Review dimension chains, drainage, supports, finishes and maintenance access, with references for design verification.
---

# NodeCAD 建筑节点大样助手

没有图集、规范、参考 DWG 或网络时，直接用项目输入和本包的构造笔记开展分析、绘制方案或审图。给定工程参数就按实值绘制，用户允许自定参数时把示例工况和尺寸写在成果上。未定值会改变构造时，列出受影响部位及可选方案。只有任务需要核对指定原页、现行条文或产品性能时才补取相应证据。

## 画图和审图

- 屋面、窗墙、地下、楼梯或坡道先看[建筑外围护与接缝](references/envelope-details.md)。确定剖切位置、完成面基准，以及水、荷载或位移的路径。
- 吊顶灯槽、轻隔墙、门套、地材与湿区看[室内节点选型与审图](references/interior-details.md)。其中包括 J502 四册图号、三本规范的适用问题和带参数的复核实例。
- 组织图纸时看[纸面表达](references/sheet-expression.md)及[制图标准应用](references/drafting-standards.md)。按构造特征选剖口，区分轮廓和填充，成组做法标注落在相应材料层。用户给参考图时按其表达习惯排版。
- 按[尺寸复核](references/dimension-review.md)检查完成面、起止点和标注值。竖向细部优先共用一根连续尺寸线，相邻段共用界面。薄层合并时在做法中保留每层厚度，并用同一测点的总厚复算。
- 输出审图意见时写明图上位置、问题、影响和修改后的复核方法。工程输入、演示假设和需要核对的依据分别标清。引用具体图号或条款时说明是否见到原页；实际纸面比例须在最终输出上量测。

## 可运行的绘图工具

从技能目录运行。命令和输入文件见[绘图工具](references/tools.md)。标准库地材剖面工具可直接生成 SVG，屋面两类 DXF 工具另需 ezdxf。其他节点可先交付带尺寸的构造方案，或按用户要求在可用 CAD 环境中另行绘制。

例如用户说“没有图集，画一个干区地砖接浮铺木地板，砖侧 30＋5＋10，木侧 29＋2＋14”，复制地材示例配置，核两侧完成面和盖条搭接，生成 SVG，随图说明型材、缝宽和实际工程仍需核对的条件。
